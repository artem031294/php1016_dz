<?php
$string = "Строка с Русскими буквами";
//echo mb_strlen($string); //Определить длину строки
//echo "<br>";
//
//$lookingfor = "Строка";
//$strpos=mb_strpos($string, $lookingfor);
//var_dump($strpos);
//echo "<br>";
//
//
//echo mb_strtoupper($string);
//echo "<br>";
//echo mb_strtolower($string);
//echo "<br>";
//echo mb_substr($string, (mb_strlen($string)-1), mb_strlen($string));
//echo "<br>";
$data=preg_match_all("/с/", $string);
print_r($data);