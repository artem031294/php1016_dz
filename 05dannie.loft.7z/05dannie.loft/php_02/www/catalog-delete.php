<?php

$catalog = (int)$_GET['category'];

if($catalog){
    require_once '../connect.php';
    $sql = "DELETE FROM catalogs WHERE id = ?";

    if($stmt = $mysql->prepare($sql)){

        $stmt->bind_param('i', $catalog);
        $stmt->execute();

    }
}

header('HTTP/1.1 307 Temporary Redirect');
header('Location: catalog.php');
exit;