<?php

require_once '../connect.php';
$product = (int)$_GET['product'];

$sql = "SELECT * FROM products WHERE id_product = ?";

$stmt = $mysql->prepare($sql);
$stmt->bind_param('i', $product);
$stmt->execute();

$result = $stmt->get_result();
$record = $result->fetch_assoc();
?>
<html>
    <head>
        <title>Редактирование товара</title>
        <style type="text/css">
            div{
                margin-bottom: 10px;
            }
        </style>
    </head>
    <form action="update-product.php" method="post">
        <input type="hidden" name="id_product" value="<?php echo $record['id_product']; ?>">
        <input type="hidden" name="id_catalog" value="<?php echo $record['id_catalog']; ?>">
        <div>
            <label for="name">Название товара</label>
            <input type="text" name="name" id="name" value="<?php echo $record['name']; ?>">
        </div>
        <div>
            <label for="price">Цена товара</label>
            <input type="text" name="price" value="<?php echo $record['price']; ?>">
        </div>
        <div>
            <label for="count">Количество товара</label>
            <input type="text" name="count" value="<?php echo $record['count']; ?>">
        </div>
        <div>
            <label for="mark">Марка товара</label>
            <input type="text" name="mark" value="<?php echo $record['mark']; ?>">
        </div>
        <div>
            <label for="description">Описание товара</label><br />
            <textarea name="description" id="description" cols="30" rows="10"><?php echo $record['description']; ?></textarea>
        </div>
        <div>
            <input type="submit" value="Редактировать товара">
            <input type="button" value="Отменить" onClick="window.location.href='catalog-items.php?category=<?=$record['id_catalog']?>';">
        </div>
    </form>
</html>
