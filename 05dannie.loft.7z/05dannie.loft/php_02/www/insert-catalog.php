<?php
require_once '../connect.php';

$name = $_POST['name'];
$name = trim($name);
$name = htmlentities($name, ENT_QUOTES);
$mysql->real_escape_string($name);

if(mb_strlen($name)){
    $sql = "INSERT INTO catalogs(id, name) VALUES(NULL, ?)";
    $stmt = $mysql->prepare($sql);
    $stmt->bind_param('s', $name);

    $stmt->execute();
    $stmt->close();
    $mysql->close();
}

header('HTTP/1.1 307 Temporary Redirect');
header('Location: catalog.php');
exit;