<?php
require_once '../connect.php';
$id_product = (int)$_POST['id_product'];
$id_catalog = (int)$_POST['id_catalog'];
$name = htmlentities(strip_tags(trim($_POST['name'])), ENT_QUOTES);
$mark = htmlentities(strip_tags(trim($_POST['mark'])), ENT_QUOTES);
$description = htmlentities(strip_tags(trim($_POST['description'])), ENT_QUOTES);
$price = (double)$_POST['price'];
$count = (int)$_POST['count'];

$sql = "UPDATE products SET name = ?, price = ?, count = ?, mark = ?, description = ?
       WHERE id_product = ?";

if($stmt = $mysql->prepare($sql)){

    $stmt->bind_param('sdidsi', $name, $price, $count, $mark, $description, $id_product);
    $stmt->execute();

    header('HTTP/1.1 307 Temporary Redirect');
    header('Location: catalog-items.php?category='.$id_catalog);
    exit;
}