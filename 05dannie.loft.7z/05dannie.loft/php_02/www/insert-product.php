<?php
require_once '../connect.php';
$id_catalog = (int)$_POST['id_catalog'];
$name = htmlentities(strip_tags(trim($_POST['name'])), ENT_QUOTES);
$mark = htmlentities(strip_tags(trim($_POST['mark'])), ENT_QUOTES);
$description = htmlentities(strip_tags(trim($_POST['description'])), ENT_QUOTES);
$price = (double)$_POST['price'];
$count = (int)$_POST['count'];


$sql = "INSERT INTO products(name, price, count, mark, description, id_catalog)
                    VALUES (?, ?, ?, ?, ?, ?)";

if($stmt = $mysql->prepare($sql)){

    $stmt->bind_param('sdidsi', $name, $price, $count, $mark, $description, $id_catalog);
    $stmt->execute();

    header('HTTP/1.1 307 Temporary Redirect');
    header('Location: catalog-items.php?category='.$id_catalog);
    exit;
}




