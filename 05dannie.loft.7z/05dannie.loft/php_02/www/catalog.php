<?php

require_once '../connect.php';

$sql_catalog = "SELECT id, name FROM catalogs";
$result = $mysql->query($sql_catalog);

$catalogs = $result->fetch_all(MYSQLI_ASSOC);

echo "<h1>Список категорий каталога</h1>";

echo "<p><a href='add-catalog.php' style='color:green;'>Добавить категорию</a></p>";
if (count($catalogs)) {

    echo "
    <table border='1' style='border-collapse: collapse;'' cellpadding='7'>
        <tr>
            <th>#</th>
            <th>Наименование категории</th>
            <th>Удалить</th>
        </tr>
    ";

    $l = 1;
    foreach($catalogs as $catalog){
        echo "
            <tr>
                <td>{$l}</td>
                <td><a href='catalog-items.php?category={$catalog['id']}'>{$catalog['name']}</a></td>
                <td><a href='catalog-delete.php?category={$catalog['id']}'>удалить</a></td>
            </tr>
            ";
        $l++;
    }

    echo "</table><hr />";

    echo "Всего категорий в магазине - ".count($catalogs);

} else {
    echo "<p>Списк пуст</p>";
}