<?php

$category = (int)$_GET['category'];

if($category){
    require_once '../connect.php';

    $sql = "SELECT products.id_product, products.name, products.count, products.description, FORMAT(products.price, 2) as price
        FROM products WHERE products.id_catalog = ?";

    if($stmt = $mysql->prepare($sql)){

        $stmt->bind_param('i', $category);
        $stmt->execute();
        $result = $stmt->get_result();
        echo "<a href='add-product.php?category={$category}'>Добавить продукт</a><br /><br />";
        if($result->num_rows){
            $products = $result->fetch_all(MYSQLI_ASSOC);

            echo <<<TABLE
            <table border="1" style="border-collapse: collapse;" cellpadding="7">
                <thead>
                    <th>Название товара</th>
                    <th>Цена (руб.)</th>
                    <th>Кол-во (шт.)</th>
                    <th>Описание</th>
                    <th></th>
                </thead>
                <tbody>
TABLE;
            foreach($products as $product){
                echo "<tr>
                <td>{$product['name']}</td>
                <td style='text-align: center;'>{$product['price']} руб.</td>
                <td style='text-align: center;'>{$product['count']}</td>
                <td>{$product['description']}</td>
                <td>
                    <a href='edit-product.php?product={$product['id_product']}'>Редактировать</a>&nbsp;
                    <a href='delete-product.php?product={$product['id_product']}&catalog={$category}'>Удалить</a>
                </td>
</tr>";
            }

            echo <<<ENDTABLE
            </tbody>
            </table>
ENDTABLE;

        } else {
            echo "Список товаров категории пуст<br />";
        }

    } else {
        echo "Ошибка при формировании запроса";
    }
} else {
    echo "ОШИБКА 404";
}
echo "<br /><a href='catalog.php'>Вернуться к каталогу</a><br />";

