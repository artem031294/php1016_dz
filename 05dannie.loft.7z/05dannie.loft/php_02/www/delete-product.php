<?php

$product = (int)$_GET['product'];
$catalog = (int)$_GET['catalog'];

if($product){
    require_once '../connect.php';
    $sql = "DELETE FROM products WHERE id_product = ?";

    if($stmt = $mysql->prepare($sql)){

        $stmt->bind_param('i', $product);
        $stmt->execute();

    }
}

header('HTTP/1.1 307 Temporary Redirect');
header('Location: catalog-items.php?category='.$catalog);
exit;