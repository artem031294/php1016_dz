<html>
    <head>
        <meta charset="utf-8">
        <title>Добавление категории</title>
    </head>
    <body>
        <h1>Добавление категории</h1>
        <form action="insert-catalog.php" method="post">
            <div>
                <label for="name">Название категории: </label>
                <input type="text" name="name" id="name">
            </div>
            <hr>
            <div>
                <input type="submit" value="Добавить">
                <input type="button" value="Отменить" onClick="window.location.href='catalog.php';">
            </div>
        </form>

    </body>
</html>