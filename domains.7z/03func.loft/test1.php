<?php

$lang = 'php';
return $lang;