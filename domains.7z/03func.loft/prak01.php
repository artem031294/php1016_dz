<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Практикум №1</title><link rel="stylesheet" href="style.css"></head><body><h1>Практикум №1 - "Функции и аргументы"</h1><a href=".">вернуться</a><hr>

<?php

///* Ex.1 - простое создание функции */
// function func() {
//     return 'Внутри функции<br>';
// }
// echo func();

/* Ex.2 - аргументы, аргументы по умолчанию */
// function func($name, $age = 25){
//     echo 'Имя: '.$name.'<br>';
//     echo 'Возраст: '.$age.'<br>';
//     echo '=====================================<br>';
// }
// func('Пётр');
// func('Василий',34);

/* Ex.3 - переменное количество аргументов */
// function func() {
//     $num_args = func_num_args();
//     echo 'Аргументов передано: '.$num_args.'<br>';
//     if ($num_args > 0) {
//         for($i = 0; $i < $num_args; $i++) {
//             echo 'Аргумент ('.$i.') == '.func_get_arg($i).'<br>';
//         }
//         $arr_args = func_get_args();
//         echo '<pre>'.print_r($arr_args, true).'</pre>';
//     }
//     echo '=====================================<br>';
// }
//
// func();
// func(1,2,3);
// func('qqq','www','rrr','ttt','yyy','uuu',Array(99,88,77,66,55,44));


/* Ex.4 - Ссылочные аргументы */
// function func2(&$name){
//     echo 'Привет, '.$name.'! (внутри функции)<br>';
//     $name = 'Ира (изменили внутри функции)';
// }
// $name = 'Коля';
// echo 'Привет, '.$name.'!<br>';
// func2($name);
// echo 'Привет, '.$name.'!<br>';
//
//// func2('Петя'); // ОШИБКА !!!

//func1();
//func1_1();

function func1()
{
    function func1_1() {
        echo 'func1_1';
    }

    echo 'func1';
//    func1_1();
}

//func1_1();

?>

</body>
</html>