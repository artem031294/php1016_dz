<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Практикум №2</title><link rel="stylesheet" href="style.css"></head><body><h1>Практикум №2 - "Возвращение значений"</h1><a href=".">вернуться</a><hr>

<?php
//error_reporting(-1);

/* Ex.1 - простое создание функции */
// function func(){
//     return 'Вернулось из функции';
//     echo 'Мёртвый код';
//     return;
//     echo 'Мёртвый код №2';
// }
// $str = func();
// echo $str;

/* Ex.2 - возвращение массива */
// function arr(){
//     return Array('Василий',25, Array('+7(777)777-77-77','+7(555)555-55-55'));
// }
// $arr = arr();
// echo '<pre>'.print_r($arr,true).'</pre>';

// list($name, $age, $phones) = arr();
// //echo $name,$age,$phones;
// //list($name, , $phones) = arr();
// list($name, , $phones, $temp) = arr();

// echo 'Возраст ('.$arr[0].'): '.$arr[0].' лет';

/* Ex.3 - подключение файлов*/
// $res = include 'test1.php';
// echo 'test1: '. $res .'<br>';

 require "test2.php";
 function connectToDb($host, $user, $pwd) {
     echo "$host $user $pwd";
 }
connectToDb($dbhost, $dbuser, $dbpasswd);

?>

</body>
</html>