<?php
return "asd";
$lang = 'c#';
$lang2 = 'c#';

$dbhost = "localhost";
$dbuser = "root";
$dbpasswd = "no";
