<?php
//require "prak01.php";
//include_once
//require_once
class SuperClass
{
    function a() {
        echo "a";
    }

    function b() {

    }

    function isOver18($age) {
        if ($age > 18 && $age < 21) {
            return ['пиво'];
        } elseif ($age >= 21) {
            return ['пиво', 'водка'];
        } else {
            return false;
        }
    }
    function sell(){
        echo "Продано!";
    }
}




function isOver18($age) {
    if ($age > 18 && $age < 21) {
        return ['пиво'];
    } elseif ($age >= 21) {
        return ['пиво', 'водка'];
    } else {
        return false;
    }
}

$data = isOver18(20);
print_r($data);