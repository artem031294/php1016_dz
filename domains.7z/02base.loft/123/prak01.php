<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Практикум №1</title>
    <link rel="stylesheet" href="style.css">
</head>
<body><h1>Практикум №1 - "Вывод"</h1><a href=".">вернуться</a>
<hr>

<?php

// Однострочный комментарий
echo 'Вывод информации<br>'; // Однострочный комментарий до конца строки
echo 'строка1<br>', 'строка2<br>', 'строка3<br>'; # Другой однострочный комментарий до конца строки

echo('Ещё строка<br>');
//echo ('ошибка1<br>', 'ошибка2<br>', 'ошибка3<br>');

print 'print<br>';
print ('other print<br>');
// print 'ошибка1<br>', 'ошибка2<br>', 'ошибка3<br>';
// print ('ошибка1<br>', 'ошибка2<br>', 'ошибка3<br>');

$a = ['arr1', 'arr2'];
print_r($a);
$b = array('arr1', 'arr2', 'arr3', 'arr4', 'arr5');
print_r($b);

?>

</body>
</html>