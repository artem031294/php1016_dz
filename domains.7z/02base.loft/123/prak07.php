<?php
//
//// try {
////     $a = 5;
////     $b = 0;
////
////     $t = $a / $b;
////
//// } catch (Exception $ex) {
////     print_r($ex);
//// } finally {
////     echo 'выполнится всё равно';
//// }
//
//try {
//    $a = 5;
//    $b = 0;
//
//    if ($b == 0) {
//        throw new Exception('Деление на ноль.');
//    }
//
//    $t = $a / $b;
//
//} catch (Exception $ex) {
////    echo "Произошло деление на ноль";
////    echo '<pre>';
//    print_r($ex->getMessage());
////    echo '</pre>';
//}
//echo "Hello";
//


$arr = ['a' =>  'a1', 'b'   => 'b1'];
echo $arr[0];