<?php

$user1=[
    'id' => 1,
    'name' => 'Igor'
];

$user2=[
    'id' => 2,
    'name' => 'Igoryan'
];



$users = [ $user1, $user2];

echo json_encode($users);