<?php
session_start();
$_SESSION['name'] = "asd";
?>
<a href="/admin.php">link</a>
