<?php

echo '<h2>POST</h2><pre>';
print_r($_POST);
echo '</pre>';