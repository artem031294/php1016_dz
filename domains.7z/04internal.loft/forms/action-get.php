<?php

echo '<h2>GET</h2><pre>';
print_r($_GET);
echo '</pre>';