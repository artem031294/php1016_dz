<?php
// header('Content-Type: text/html');
header('Content-Type: text/plain');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <h1>New Document</h1>
</body>
</html>